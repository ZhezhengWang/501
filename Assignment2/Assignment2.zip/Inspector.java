import java.lang.reflect.*;
import java.util.HashSet;
import java.util.Set;

public class Inspector {
    private final Set<Object> inspectedObjects = new HashSet<>();

    public void inspect(Object obj, boolean recursive) {
        inspectedObjects.clear();
        introspect_Object(obj, recursive, 0);
    }

    //
    //check if Object is null
    //
    private void introspect_Object(Object obj, boolean recursive, int depth) {
        if (obj == null) {
            print_Indentation("Object is null.", depth);
            return;
        }

        Class<?> clazz = obj.getClass();
        //
        // Indentation for formatting
        //
        print_Class_Info(clazz, depth);
        if (inspectedObjects.contains(obj)) {
            print_Indentation("Object has already been inspected.", depth);
            return;
        }

        inspectedObjects.add(obj);

        for (Method method : clazz.getDeclaredMethods()) {
            intro_Method(method, depth);
        }
        for (Constructor<?> constructor : clazz.getDeclaredConstructors()) {
            intro_Constructor(constructor, depth);
        }
        for (Field field : clazz.getDeclaredFields()) {
            intro_Field(field, obj, recursive, depth);
        }
    }

    //
    // Print class name and superclass name
    //
    private void print_Class_Info(Class<?> clazz, int depth) {
        print_Indentation("Name of declaring class: " + clazz.getName(), depth);
        print_Indentation("Name of superclass: " + clazz.getSuperclass().getName(), depth);
        print_Interfaces(clazz, depth);
    }

    //
    // Print names of implemented interfaces
    //
    private void print_Interfaces(Class<?> clazz, int depth) {
        Class<?>[] interfaces = clazz.getInterfaces();
        if (interfaces.length > 0) {
            StringBuilder interface_Info = new StringBuilder("Names of interfaces: ");
            for (Class<?> interf : interfaces) {
                interface_Info.append(interf.getName()).append("");
            }
            print_Indentation(interface_Info.toString(), depth);
        } else {
            print_Indentation("No implemented interfaces.", depth);
        }
    }

    //
    //The methods the class declares. For each, also find the following:
    //The exceptions thrown
    //The parameter types
    //The return type
    //The modifiers
    //
    private void intro_Method(Method method, int depth) {
        print_Indentation("Method name:" + method.getName(), depth);
        print_Array_Indentation("Exceptions Thrown", method.getExceptionTypes(), depth + 1);
        print_Array_Indentation("Parameter types", method.getParameterTypes(), depth + 1);
        print_Indentation("Return Type:" + method.getReturnType().getName(), depth + 1);
        print_Indentation("Modifiers:" + Modifier.toString(method.getModifiers()), depth + 1);
    }

    //
    //The constructors the class declares. For each, also find the following:
    //The parameter types
    //The modifiers
    //
    private void intro_Constructor(Constructor<?> constructor, int depth) {
        print_Indentation("Constructor name:" + constructor.getName(), depth);
        print_Array_Indentation("Parameter types", constructor.getParameterTypes(), depth + 1);
        print_Indentation("Modifiers:" + Modifier.toString(constructor.getModifiers()), depth + 1);
    }

    //
    //The fields the class declares. For each, also find the following:
    //The type
    //The modifiers
    //Use try catch to get values, Exception Type and Exception Messages
    //
    private void intro_Field(Field field, Object obj, boolean recursive, int depth) {
        field.setAccessible(true);
        print_Indentation("Field name:" + field.getName(), depth);
        print_Indentation("Type:" + field.getType().getName(), depth + 1);
        print_Indentation("Modifies:" + Modifier.toString(field.getModifiers()), depth + 1);
        try {
            Object value = field.get(obj);
            if (value != null && recursive) {
                print_Indentation("Value:", depth + 1);
                introspect_Object(value, true, depth + 2);
            } else {
                print_Indentation("Value:" + value, depth + 1);
            }
        } catch (IllegalAccessException exc) {
            print_Indentation("Exception Type:" + exc.getClass().getName(), depth + 1);
            print_Indentation("Exception Message:" + exc.getMessage(), depth + 1);
        }
    }


    //
    //print_Indentation and print_Array_Indentation are for better output indentation
    //
    private void print_Indentation(String message, int depth) {
        System.out.println("".repeat(depth) + message);
    }

    private <T> void print_Array_Indentation(String prefix, T[] array, int depth) {
        if (array.length == 0) return;
        StringBuilder builder = new StringBuilder(prefix + ":");
        for (T element : array) {
            builder.append(element.toString()).append("");
        }
        print_Indentation(builder.toString(), depth);
    }
}
