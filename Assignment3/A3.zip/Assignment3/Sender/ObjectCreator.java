package org.jdom;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Scanner;

public class ObjectCreator {

	private static ObjectCreator INSTANCE;

	private Scanner in;

	private ObjectCreator() {
		in = new Scanner(System.in);
	}

	public static ObjectCreator getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new ObjectCreator();
		}
		return INSTANCE;
	}

	private void print(String str, int depth) {
		System.out.print(" ".repeat(depth) + str);
	}

	private Object readPrimitiveValue(Class<?> type) throws NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		String value = in.next();

		Class<?> boxed = Array.get(Array.newInstance(type, 1), 0).getClass();

		Method valueOfMethod = boxed.getDeclaredMethod("valueOf", String.class);

		return valueOfMethod.invoke(null, value);
	}

	Object inputFieldValue(Field field, int depth) throws NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Object obj = null;
		print("Please enter value for " + field.getName() + "(" + field.getType().getName() + "): ", depth);
		if (field.getType().isPrimitive()) {
			obj = readPrimitiveValue(field.getType());
		} else if (field.getType().getName() == "String") {
			String value = in.next();
			obj = value;
		} else if (field.getType().getName().startsWith("[")) {
			// Array Type
			String fieldName = field.getName();
			Class<?> fieldType = field.getType();
			Class<?> fieldComponentType = fieldType.getComponentType();
			System.out.println();
			print("Please enter the size of Array " + fieldName + ": ", depth);
			String value = in.next();
			int n = Integer.valueOf(value).intValue();
			if (n > 0) {
				obj = Array.newInstance(fieldComponentType, n);
				for (int i = 0; i < n; i++) {
					print("Please enter value for " + fieldName + "[" + i + "] (" + fieldComponentType.getName()
							+ "): ", depth + 1);
					Object val = inputObjectValue(null, fieldComponentType, depth + 2);
					Array.set(obj, i, val);
				}
			}
		} else {
			System.out.println();
			obj = inputObjectValue(null, field.getType(), depth + 1);
		}

		return obj;
	}

	public Object inputObjectValue(Object obj, Class<?> type, int depth) {

		try {
			if (type.isPrimitive()) {
				obj = readPrimitiveValue(type);
			} else {

				if (obj == null)
					obj = type.getDeclaredConstructor().newInstance();

				Field fields[] = type.getDeclaredFields();

				for (Field field : fields) {
					Object fieldValue = inputFieldValue(field, depth);
					field.setAccessible(true);
					field.set(obj, fieldValue);
				}

				if (type.getSuperclass() != null) {
					inputObjectValue(obj, type.getSuperclass(), depth);
				}
			}
		} catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
				| NoSuchMethodException | SecurityException e) {
			e.printStackTrace();
		}

		return obj;
	}

}
