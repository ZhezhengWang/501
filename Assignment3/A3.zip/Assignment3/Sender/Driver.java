package org.jdom;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.util.Scanner;

import org.w3c.dom.Document;

public class Driver {

	public int depth;
	public Scanner in;
	private static Driver INSTANCE;

	private Driver() {
		depth = 0;
		in = new Scanner(System.in);
	}

	public static Driver getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new Driver();
		}
		return INSTANCE;
	}

	public static void main(String[] args) throws FileNotFoundException {

		Driver driver = Driver.getInstance();
		String className = "ClassE";
		boolean isClassValid;
		
		int port = 8056;

		System.out.println("Welcome to the object Serializer");

		while (true) {
			System.out.println("Please enter the class name: ");
			className = driver.in.next();

			isClassValid = driver.isClassValid(className);

			if (isClassValid) {
				try {
					ObjectCreator oc = ObjectCreator.getInstance();
					Class<?> clazz = driver.forName(className);
					if (clazz == null) {
						System.out.println("Class not found. Please ensure it is available in the classpath.");
						continue;
					}
					System.out.println("Please enter object values: ");
					Object obj = oc.inputObjectValue(null, clazz, 0);
					if (obj == null) {
						System.out.println("Unable to create an instance of " + className + ". Please ensure it has a public no-argument constructor.");
						continue;
					}
					Serializer ser = new Serializer();
					Document doc = ser.serialize(obj);
					SocketSender sender = new SocketSender();

					String str = ser.printDocumentToString(doc);

					System.out.println("Sending the DOM to the server ");
					sender.sendDomToServer(InetAddress.getLocalHost(), port, str);

				} catch (Exception e) {
					System.out.println("An error occurred, please try again.");
					e.printStackTrace();
				}

			} else {
				System.out.println("Invalid class name. Exiting the program.");
			}
		}
	}

	private void print(String str) {
		System.out.println(" ".repeat(depth) + str);
	}

	private Class<?> forName(String className) {
		Class<?> cls = null;
		try {
			cls = Class.forName(className);
		} catch (ClassNotFoundException e) {
			try {
				cls = Class.forName(this.getClass().getPackageName() + "." + className);
			} catch (ClassNotFoundException e1) {
			}
		}
		return cls;
	}

	private boolean isClassValid(String className) {
		boolean isValid = false;
		Class<?> cls = forName(className);

		if (cls != null) {
			if (java.io.Serializable.class.isInstance(cls)) {
				isValid = true;
			}
		}

		return isValid;
	}

}
