package org.jdom;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

public class SocketReceiver {
    private ServerSocket server;
    private int port = 9876;
    
    public void setupServer(int p) throws IOException {
    	port = p;
    	server = new ServerSocket(port);
    }
    
    public String receiveDomFromClient()  throws UnknownHostException, IOException, ClassNotFoundException, InterruptedException{
			Socket socket = server.accept();
			ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
			String message = (String) ois.readObject();
			System.out.println(message);
			ois.close();
			socket.close();
			
			return message;
	}
    
    public boolean tearDown() {
    	if (server.isClosed())
    		return true;
    	return false;
    }

}