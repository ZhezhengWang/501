package org.jdom;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.w3c.dom.Document;

public class Driver {

	public static void main(String[] args) throws FileNotFoundException {

		SocketReceiver receiver = new SocketReceiver();
		int port = 8056;

		try {
			receiver.setupServer(port);
		} catch (IOException e) {
			System.out.println("Failed to create a server socket on port: " + port);
			return;
		}
		System.out.println("Welcome to the object Deserializer");

		while (true) {
			try {
				System.out.println("Waiting for Dom object ...");
				String str = null;
				try {
					str= receiver.receiveDomFromClient();
				} catch (Exception ex) {
					System.out.println("Something went wrong with the socket. Quitting ...");
					return;
				}
				System.out.println("Dom object Received Deserializing ...");
				Deserializer der = new Deserializer();
				Document dom = der.loadXMLFromString(str);
				Object obj = der.deserialize(dom);
				Serializer ser = new Serializer();

				System.out.println("Inspecting ...");
				
				Document inspectionDom = ser.serialize(obj);
				
				String receivedStr = ser.printDocumentToString(inspectionDom);
				
				System.out.println("Received and deserialized Object: ");
				System.out.println(receivedStr);
			} catch (Exception ex) {
				System.out.println("Invalid Dom trying again ...");
			}
		}
	}
}
