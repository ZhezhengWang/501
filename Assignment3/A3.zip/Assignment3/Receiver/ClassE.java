package org.jdom;

public class ClassE {
    @SuppressWarnings("unused")
	private ClassA[] vallarray = new ClassA[10];
}
