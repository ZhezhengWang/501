package org.jdom;

import java.io.*;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class Serializer {

	// A unique counter to generate IDs for serialized objects
	private static int idCounter = 0;

	// A list to keep track of all serialized object elements
	private List<Element> objectElements = new ArrayList<>();

	// Increment and get a new unique ID as a string
	private static String getNewID() {
		return String.valueOf(++idCounter);
	}

	// Method to serialize an object into an XML Document
	public Document serialize(Object obj) throws IllegalAccessException, ParserConfigurationException {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.newDocument();

		// Create the root element of the XML
		Element serialized = doc.createElement("serialized");
		doc.appendChild(serialized);

		// Create the XML element for the given object and add it to the root
		createObjectElement(doc, obj, null);
		for (Element element : objectElements) {
			serialized.appendChild(element);
		}

		return doc;
	}

	// Create an XML element representing an object, including its fields
	private String createObjectElement(Document doc, Object obj, Field containingField) throws IllegalAccessException {
		Element elem = doc.createElement("object");
		String id = getNewID();
		elem.setAttribute("id", id);
		elem.setAttribute("class", containingField == null ? obj.getClass().getName() : containingField.getType().getName());

		if (obj.getClass().isArray()) {
			serializeArray(obj, elem, doc);
		} else {
			serializeFields(obj, elem, doc);
		}

		objectElements.add(elem);
		return id;
	}

	// Serialize all fields of the object
	private void serializeFields(Object obj, Element objElement, Document doc) throws IllegalAccessException {
		for (Field field : obj.getClass().getDeclaredFields()) {
			field.setAccessible(true);
			Element fieldElement = createFieldElement(doc, field, obj);
			objElement.appendChild(fieldElement);
		}
	}

	// Serialize the given array object
	private void serializeArray(Object array, Element arrayElement, Document doc) throws IllegalAccessException {
		int length = Array.getLength(array);
		arrayElement.setAttribute("length", Integer.toString(length));

		for (int i = 0; i < length; i++) {
			Object arrayItem = Array.get(array, i);
			Element contentElement = createContentElement(doc, arrayItem, null);
			arrayElement.appendChild(contentElement);
		}
	}

	// Create an XML element for a field of an object
	private Element createFieldElement(Document doc, Field field, Object obj) throws IllegalAccessException {
		Element fieldElem = doc.createElement("field");
		fieldElem.setAttribute("name", field.getName());
		fieldElem.setAttribute("declaringclass", field.getDeclaringClass().getName());

		Object value = field.get(obj);
		Element contentElem = createContentElement(doc, value, field);
		fieldElem.appendChild(contentElem);

		return fieldElem;
	}

	// Create an XML element representing the content of an object's field
	private Element createContentElement(Document doc, Object value, Field field) {
		Element contentElem;

		if (field != null && field.getType().isPrimitive()) {
			// If the field is primitive, store the value directly
			contentElem = doc.createElement("value");
			contentElem.setTextContent(String.valueOf(value));
		} else {
			// For objects, use a reference to the object's ID
			contentElem = doc.createElement("reference");
			String objectId = getNewID();
			contentElem.setTextContent(objectId);
			// Recursively serialize the object
			if (value != null) {
				try {
					createObjectElement(doc, value, field);
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				}
			}
		}

		return contentElem;
	}

	// Print the XML document to an output stream
	public void printDocument(Document doc, OutputStream out) throws TransformerException, IOException {
		Transformer transformer = setupTransformer();
		transformer.transform(new DOMSource(doc), new StreamResult(new OutputStreamWriter(out, "UTF-8")));
	}

	// Convert the XML document to a string
	public String printDocumentToString(Document doc) throws TransformerException, UnsupportedEncodingException {
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		Transformer transformer = setupTransformer();
		transformer.transform(new DOMSource(doc), new StreamResult(new OutputStreamWriter(outputStream, "UTF-8")));
		return outputStream.toString("UTF-8");
	}

	// Setup the XML transformer with the required properties
	private Transformer setupTransformer() throws TransformerException {
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		transformer.setOutputProperty(OutputKeys.METHOD, "xml");
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
		transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
		return transformer;
	}
}
