package org.jdom;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;

public class Deserializer {
	// Map to hold the objects created during deserialization, keyed by ID.
	private HashMap<String, Object> objectMap = new HashMap<>();
	private Document document;

	// Converts an XML string to a Document object.
	public Document loadXMLFromString(String xml) throws Exception {
		return loadXML(new ByteArrayInputStream(xml.getBytes()));
	}

	// Converts an XML file to a Document object.
	public Document loadXMLFromFile(String file) throws Exception {
		return loadXML(new FileInputStream(file));
	}

	// Loads an XML document from an InputStream.
	private Document loadXML(InputStream inputStream) throws Exception {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder builder = factory.newDocumentBuilder();
		return builder.parse(inputStream);
	}

	// Main method to deserialize an object from an XML Document.
	public Object deserialize(Document doc) throws Exception {
		document = doc;
		loadAllObjects();
		return objectMap.get("1"); // Assuming "1" is the ID of the root object.
	}

	// Reads all "object" elements from the XML and instantiates their corresponding Java objects.
	private void loadAllObjects() throws Exception {
		NodeList objects = document.getElementsByTagName("object");
		for (int i = 0; i < objects.getLength(); i++) {
			Element elem = (Element) objects.item(i);
			instantiateObject(elem);
		}
	}

	// Instantiates an object and puts it in the objectMap based on its XML element.
	private void instantiateObject(Element elem) throws Exception {
		String className = elem.getAttribute("class");
		Class<?> clazz = forName(className);
		Object obj;

		if (!className.startsWith("[")) {
			obj = clazz.getDeclaredConstructor().newInstance();
			objectMap.put(elem.getAttribute("id"), obj);
			populateFields(clazz, elem, obj);
		} else {
			obj = createArray(clazz, elem);
			objectMap.put(elem.getAttribute("id"), obj);
		}
	}

	// Populates the fields of an instantiated object using reflection.
	private void populateFields(Class<?> clazz, Element elem, Object obj) throws Exception {
		NodeList fieldElems = elem.getElementsByTagName("field");
		for (int j = 0; j < fieldElems.getLength(); j++) {
			Element fieldElem = (Element) fieldElems.item(j);
			Field field = clazz.getDeclaredField(fieldElem.getAttribute("name"));
			field.setAccessible(true);
			field.set(obj, getFieldValue(field, fieldElem));
		}
	}

	// Gets the value for a field from an XML element, handling both primitive and object references.
	private Object getFieldValue(Field field, Element fieldElem) throws Exception {
		if (field.getType().isPrimitive()) {
			return loadPrimitiveValue(field.getType(), fieldElem);
		} else {
			return objectMap.get(fieldElem.getElementsByTagName("reference").item(0).getTextContent());
		}
	}

	// Creates an array based on its XML element description.
	private Object createArray(Class<?> clazz, Element elem) throws Exception {
		int length = Integer.parseInt(elem.getAttribute("length"));
		Class<?> componentType = clazz.getComponentType();
		Object array = Array.newInstance(componentType, length);
		NodeList valueElems = elem.getElementsByTagName("value");
		NodeList refElems = elem.getElementsByTagName("reference");
		for (int k = 0; k < length; k++) {
			Object val = (refElems.getLength() > 0) ? objectMap.get(refElems.item(k).getTextContent()) :
					loadPrimitiveValueFromText(componentType, (Element) valueElems.item(k));
			Array.set(array, k, val);
		}
		return array;
	}

	// Loads a primitive value from an XML element.
	private Object loadPrimitiveValue(Class<?> type, Element element) throws Exception {
		return loadPrimitiveValueFromText(type, (Element) element.getElementsByTagName("value").item(0));
	}

	// Converts a text value into its corresponding primitive/object type.
	private Object loadPrimitiveValueFromText(Class<?> type, Element element) throws Exception {
		String value = element.getTextContent();
		Method valueOfMethod = type.getMethod("valueOf", String.class);
		return valueOfMethod.invoke(null, value);
	}

	// Resolves the class name into a Class object, handling array class names.
	private Class<?> forName(String className) throws ClassNotFoundException {
		if (className.startsWith("[")) {
			return getArrayClass(className);
		} else {
			try {
				return Class.forName(className);
			} catch (ClassNotFoundException e) {
				// Try with the package name
				return Class.forName(this.getClass().getPackageName() + "." + className);
			}
		}
	}

	// Resolves the class name for arrays.
	private Class<?> getArrayClass(String className) throws ClassNotFoundException {
		// Implementation needed for resolving array classes
		throw new UnsupportedOperationException("Array class resolution not implemented");
	}
}
