package org.jdom;
@SuppressWarnings("serial")
public class ClassA implements java.io.Serializable, Runnable
{
    public ClassA() { val=3; }

    public ClassA(int i) 
	{

	    try { setVal(i); } catch(Exception e){}
	}

    public void run() { }

    public int getVal(){ return val; }
    public void setVal(int i) throws Exception
	{
	    if ( i < 0 ) 
		throw new Exception("negative value");

	    val = i;
	}

    public String toString() { return "ClassA"; }

    @SuppressWarnings("unused")
    private void printSomething() { System.out.println("Something"); }

    private int val=3;
//    @SuppressWarnings("unused")
//    private double val2 = 0.2;
//    @SuppressWarnings("unused")
//    private boolean val3 = true;
}
