package org.jdom;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;

class SerializeDeserializeTest {

	@Test
	void testLoadXMLFromString() {
		ClassA obj = new ClassA();
		
		try {
			Serializer ser = new Serializer();
			Serializer ser2 = new Serializer();
			Deserializer der = new Deserializer();
			Document dom = ser.serialize(obj);
			
			String xml = ser.printDocumentToString(dom);
			Document dom2 = der.loadXMLFromString(xml);
			
			String xml2 = ser2.printDocumentToString(dom2);
			
			xml = xml.replaceAll(" ", "").replaceAll("\r", "").replaceAll("\n", "");
			xml2 = xml2.replaceAll(" ", "").replaceAll("\r", "").replaceAll("\n", "");
			
			if (!xml.equals(xml2)) {
				fail("testLoadXMLFromString failed.");
			}
			
		} catch (Exception e) {
			fail("testLoadXMLFromString failed.");
			e.printStackTrace();
		}
	}

}
