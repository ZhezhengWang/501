package org.jdom;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class SocketSender {

	void sendDomToServer(InetAddress host, int port, String dom)  throws UnknownHostException, IOException, ClassNotFoundException, InterruptedException{
		
		Socket socket = new Socket(host, port);
		ObjectOutputStream ois = new ObjectOutputStream(socket.getOutputStream());
		ois.writeObject(dom);
		ois.close();
		socket.close();
	}
}