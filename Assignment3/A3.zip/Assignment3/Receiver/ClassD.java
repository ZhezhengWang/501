package org.jdom;
public class ClassD implements java.io.Serializable
{
    public ClassD() {}
    public ClassD(int i) { val3=i; }

    public String toString() { return "ClassD"; }
    
    public int getVal3() { return val3; }

    @SuppressWarnings("unused")
	private ClassA val = new ClassA(17);
    @SuppressWarnings("unused")
	private static ClassA val2;
    private int val3=34;
    @SuppressWarnings("unused")
	private ClassA[] vallarray = new ClassA[10];
}
