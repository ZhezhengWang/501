package org.jdom;
@SuppressWarnings("serial")
public class ClassB implements java.io.Serializable, Runnable
{
    public ClassB() throws Exception
    {
    }

    public void run() { }

    public String toString() { return "ClassB"; }

    public void func3(int a)
    {

    }

    @SuppressWarnings("unused")
	private ClassA val = new ClassA();
//    @SuppressWarnings("unused")
//    private ClassA val2 = new ClassA(12);
//    @SuppressWarnings("unused")
//    private ClassA val3;
}
