package org.jdom;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.net.InetAddress;

import org.junit.jupiter.api.Test;

class SocketReceiverTetsThread extends Thread {
    public void run() {
    	try {
    		SocketReceiver receiver = new SocketReceiver();
    		receiver.setupServer(SocketReceiverTest.TEST_SOCKET);
    		String message = receiver.receiveDomFromClient();
    		
    		if (!message.equals(SocketReceiverTest.SOCK_MESSAGE)) {
    			fail("SocketReceiver failed unexpected message received.");
    		}
    		
    		receiver.tearDown();
    		
    	} catch (Exception e) {
    		e.printStackTrace();
    		fail("SocketReceiver failed");
    	}
    }
}

class SocketReceiverTest {
	
	static String SOCK_MESSAGE = "Message 123";
	static int TEST_SOCKET = 8096;
	SocketSender sender;
	SocketReceiver receiver;

	@Test
	void testReceiveDomFromClient() {
		
		try {
			sender = new SocketSender();
			SocketReceiverTetsThread receiverThread;
			receiverThread = new SocketReceiverTetsThread();
			receiverThread.start();			

			sender.sendDomToServer(
					InetAddress.getLocalHost(), 
					SocketReceiverTest.TEST_SOCKET, 
					SocketReceiverTest.SOCK_MESSAGE);
			
			receiverThread.join();
			
		} catch (ClassNotFoundException | IOException | InterruptedException e) {
			fail("SocketSender failed");
		}
		
		
	}

}
